// Copyright Bruno Dutra 2015-2017
// Distributed under the Boost Software License, Version 1.0.
// See accompanying file LICENSE.txt or copy at http://boost.org/LICENSE_1_0.txt

#ifndef METAL_LIST_REMOVE_HPP
#define METAL_LIST_REMOVE_HPP

#include <metal/config.hpp>

#include <metal/list/remove_if.hpp>
#include <metal/lambda/lambda.hpp>
#include <metal/lambda/partial.hpp>
#include <metal/value/same.hpp>

namespace metal
{
    /// \ingroup list
    ///
    /// ### Description
    /// Removes all elements from a \list that are the same as some \value.
    ///
    /// ### Usage
    /// For any \list `l` and \value `val`
    /// \code
    ///     using result = metal::remove<l, val>;
    /// \endcode
    ///
    /// \returns: \list
    /// \semantics:
    ///     Equivalent to
    ///     \code
    ///         using result = metal::list<...>;
    ///     \endcode
    ///     where `result` contains all and only the elements in `l` which are
    ///     distinct from `val`.
    ///
    /// ### Example
    /// \snippet list.cpp remove
    ///
    /// ### See Also
    /// \see list, remove_if, copy, replace
    template<typename seq, typename val>
    using remove =
        metal::remove_if<seq, metal::partial<metal::lambda<metal::same>, val>>;
}

#endif
